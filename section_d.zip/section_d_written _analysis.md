\# Part I — Section D: Simple Comparison Questions (E19–E24)

D19 — Top Currencies by Global Payment Share (Most Recent Month)



|Currency|Global Payment Share (%)|
|-|-|
|USD|51.14|
|EUR|21.30|
|GBP|6.54|
|JPY|3.53|
|CNY|3.10|





Interpretation:

The most recent data shows a highly concentrated global payments system dominated by the US Dollar (USD), which holds a share of 51.14%, meaning that more than half of all global transactions are conducted in USD alone. The Euro (EUR), at 21.30%, is the second most widely used currency but trails the USD by nearly 30 percentage points, highlighting a substantial gap between the top two currencies.



Other currencies such as GBP (6.54%) and JPY (3.53%) maintain relatively smaller but stable roles in the system, while the Chinese Yuan (CNY), with 3.10%, ranks fifth. The sharp decline in share after the USD indicates that the global financial system is not evenly distributed but instead heavily reliant on a single dominant currency.



Chart:  D19\_top\_currencies.png



D20 — USD Share in Most Recent Global Payment Data



Value: 51.14%



Interpretation:

The USD accounts for 51.14% of global payment transactions, meaning that more than one out of every two international payments is conducted in USD. This level of dominance confirms the dollar’s position as the primary global reserve and transaction currency.



Despite ongoing discussions around reducing dependence on the USD, the data clearly indicates that no other currency currently approaches its scale or global acceptance. The persistence of such a high share reflects strong trust, liquidity, and widespread usage of the dollar in international trade and finance.



D21 — CNY/RMB Share and Rank in Global Payment Data



Values:



Share: 3.10%

Rank: 5th



Interpretation:

The Chinese Yuan (CNY/RMB) holds a share of 3.10%, placing it in 5th position among global currencies. While its presence in the top five reflects gradual internationalisation, the gap between CNY and leading currencies remains significant. For instance, the USD’s share is more than 16 times higher than that of the Yuan.



This suggests that although China is actively promoting the use of its currency in international trade, its global influence is still limited compared to long-established currencies such as USD and EUR.



D22 — Currencies Appearing Most Often in the Top 5 Across Reports

Currency	Frequency

USD	4

EUR	4

GBP	4

JPY	4

CAD	2

CNY	2

|Currency|Frequency|
|-|-|
|USD|4|
|EUR|4|
|GBP|4|
|JPY|4|
|CAD|2|
|CNY|2|



Interpretation:

The USD, EUR, GBP, and JPY each appear 4 times in the top five rankings across multiple reporting periods, demonstrating strong consistency and structural dominance in the global payment system.



In contrast, currencies such as CNY and CAD appear only 2 times, indicating that their presence in the top tier is less stable and more variable over time. This pattern suggests that while some diversification is occurring, the overall system remains dominated by a core group of well-established currencies.



D23 — Offshore RMB Economy with Highest Share



Values:



Economy: Hong Kong

Share: 75.57%



Interpretation:

Hong Kong accounts for 75.57% of offshore RMB transactions, making it the dominant center for international Yuan activity. This means that more than three-quarters of RMB usage outside mainland China is concentrated in a single financial hub.



This high concentration reflects Hong Kong’s role as a key financial gateway between China and the rest of the world. However, it also indicates that RMB internationalisation is still geographically concentrated, rather than being broadly distributed across multiple global financial centers.



D24 — Bar Chart: Top 10 Currencies by Global Payment Share



Observation:

The bar chart clearly illustrates the dominance of the USD, which stands at 51.14%, significantly higher than all other currencies. The Euro, at 21.30%, forms a second tier, while currencies such as GBP (6.54%), JPY (3.53%), and CNY (3.10%) contribute much smaller shares.



Lower-ranked currencies including CAD, HKD, AUD, SGD, and CHF each account for less than 3%, highlighting their relatively minor role in global transactions.



Interpretation:

The steep decline from USD to the remaining currencies indicates a highly unequal distribution of global payment shares. The system is heavily centralized, with one dominant currency and several smaller supporting currencies, rather than a balanced multi-currency structure.



Chart:  D24\_top\_10\_currencies.png

